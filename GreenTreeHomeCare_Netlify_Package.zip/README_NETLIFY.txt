Upload this ZIP to Netlify. The site entry file is index.html. The form posts to the current Google Apps Script lead endpoint.
